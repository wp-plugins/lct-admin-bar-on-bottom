=== LCT Admin Bar on Bottom ===
Contributors: ircary
Donate link: http://lookclassy.com/
Tags: Admin Bar, wpadminbar
Requires at least: 3.3
Tested up to: 3.9
Stable tag: 1.1.4
License: GPLv3 or later
License URI: http://opensource.org/licenses/GPL-3.0

This plugin sticks the Admin Bar to the bottom of your screen! You can choose to make this change on the front-end, back-end or both


== Description ==
This plugin sticks the Admin Bar to the bottom of your screen! You can choose to make this change on the front-end, back-end or both


== Installation ==
1. Upload the zip file contents to your Wordpress plugins directory.
2. Go to the Plugins page in your WordPress Administration area and click 'Activate' for LCT Admin Bar on Bottom.

== Screenshots ==
none

== Frequently Asked Questions ==
none


== Upgrade Notice ==
none


== Changelog ==
= 1.1.4 =
	- Tested for WP 3.9 Compapibility

= 1.1.3 =
	- fixed front-end background position (mobile)

= 1.1.2 =
	- fixed front-end background position (mobile)

= 1.1.1 =
	- fixed front-end background position

= 1.1 =
	- Tested for WP 3.8.1 Compapibility

= 1.0 =
	- First Release
